//
//  DieMauerHDAppDelegate.h
//  DieMauerHD
//
//  Created by Michael Dietz on 11.08.11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DieMauerHDAppDelegate : NSObject <UIApplicationDelegate>

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
