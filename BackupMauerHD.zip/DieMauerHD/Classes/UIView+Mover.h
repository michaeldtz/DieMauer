//
//  UIBarButtonItem+Mover.h
//  MapGameiPhone
//
//  Created by Dietz, Michael on 7/9/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UIView (Mover) 

-(void)moveUp:(float)moveBy;


@end
